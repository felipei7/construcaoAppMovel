package com.example.newapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.programa3.*

class programa3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.programa3)

        thirdButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        fifthButton.setOnClickListener {
            val intent = Intent(this, programa2::class.java)
            startActivity(intent)
        }

        twelfthButton.setOnClickListener {
            val intent = Intent(this, programa2::class.java)
            startActivity(intent)
        }

    }

    fun btTriangulo(view: View){

        val A = editText6_A.text.toString().toInt()
        val B = editText7_B.text.toString().toInt()
        val C = editText8_C.text.toString().toInt()

        val resposta : String

        resposta = if( (A < (B+C)) && (B < (A+C)) && (C < (A+B)))
            if ((A == B) && ( B == C)) "Esses valores formas um triangulo. E ele é Equilatero"
            else if ((A == B) || (B == C) || (A == C)) "Esses valores formas um triangulo. E ele é Isósceles"
            else "Esses valores formas um triangulo. E ele é Escaleno"
        else "Esses válores não formam um triângulo"

        textView4_Saida.text = resposta
    }

}
