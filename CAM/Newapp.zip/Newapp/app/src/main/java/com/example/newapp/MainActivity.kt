package com.example.newapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        firstButton.setOnClickListener {
            val intent = Intent(this, programa2::class.java)
            startActivity(intent)
        }

        fourthButton.setOnClickListener {
            val intent = Intent(this, programa3::class.java)
            startActivity(intent)
        }

        seventButton.setOnClickListener {
            val intent = Intent(this, programa4::class.java)
            startActivity(intent)
        }
    }

    fun btCoordenadas(view : View){

        val x = editText2_Entrada.text.toString().toInt()
        val y = editText3_Entrada.text.toString().toInt()

        val resposta : String

        resposta = if(x > 0 && y > 0) "Primeiro quadrante"
                    else if(x < 0 && y > 0) "Segundo quadrante"
                        else if(x < 0 && y < 0) "Terceiro quadrante"
                            else if(x > 0 && y <0) "Quarto quadrante"
                                else if(x == 0 && y != 0) "Está no eixo X"
                                    else if(x != 0 && y == 0) "Está no eixo Y"
                                        else "Está na origem"

        textView2_Saida.text = resposta
    }
}