package com.example.newapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.programa4.*

class programa4 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.programa4)

        ninethButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        tenthButton.setOnClickListener {
            val intent = Intent(this, programa2::class.java)
            startActivity(intent)
        }

        eighthButton.setOnClickListener {
            val intent = Intent(this, programa3::class.java)
            startActivity(intent)
        }
    }

    fun btIMC(view: View){
        val nome = editText_Nome.text.toString()
        val peso = editText2_Peso.text.toString().toFloat()
        val altura = editText3_Altura.text.toString().toFloat()

        val imc : Float
        imc = ((peso)/(altura*altura))*10000

        val resposta = if (imc < 20) "$nome você está abaixo do peso ideal"
        else if (imc >= 20 && imc <= 25) "$nome você está no peso Normal"
        else if (imc > 25 && imc <= 30) "$nome você está com excesso de peso"
        else if(imc > 35 && imc <= 35) "$nome você está com obesidade"
        else "$nome você está com obesidade Mórbita"

        textView5_Saida.text = resposta
    }
}
