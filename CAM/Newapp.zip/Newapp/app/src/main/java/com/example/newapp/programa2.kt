package com.example.newapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.progama2.*

class programa2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.progama2);

        secondButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        sixthButton.setOnClickListener {
            val intent3 = Intent(this, programa3::class.java)
            startActivity(intent3)
        }

        eleventhButton.setOnClickListener {
            val intent3 = Intent(this, programa4::class.java)
            startActivity(intent3)
        }
    }


    fun btPeso(view : View){
        val pesoTerra = editText4_PesoNaTerra.text.toString().toFloat()
        val nomePlaneta = editText5_NomePlaneta.text.toString()

        val pesoPlaneta : Float
        val gravidade_Relativa : Float

        if(nomePlaneta == "jupiter") gravidade_Relativa = 2.64f
        else if(nomePlaneta == "saturno") gravidade_Relativa = 1.15f
        else gravidade_Relativa = 1.17f

        pesoPlaneta = (pesoTerra * gravidade_Relativa)/10f

        pesoPlaneta.toString()

        textView5_Saida.setText("$pesoTerra kg na terra é igual a $pesoPlaneta kg em $nomePlaneta")
    }

}
