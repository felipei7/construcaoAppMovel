package com.example.app3telas.classes

import kotlin.math.sqrt

enum class FiguraGeo(var shorthand: String){
    Esfera("Esfera"),
    Cilindro("Cilindro"),
    Cone("Cone")
}

interface calcularGeo{
    fun calcularAreaTotal(raio : Double) : Double
    fun calcularVolume(raio : Double) : Double
    fun calcularFigura() : FiguraGeo
}


class esfera() : calcularGeo{

    override fun calcularAreaTotal(raio : Double) : Double{
        return ((4*3.14)*(raio*raio))
    }

    override fun calcularVolume(raio : Double) : Double{
        return (((4*3.14)*(raio*raio*raio))/3)
    }

    override fun calcularFigura() : FiguraGeo{
        return FiguraGeo.Esfera
    }
}

abstract class cilindroF() {

    abstract fun calcularAreaTotal(raio : Double, altura : Double) : Double

    abstract fun calcularFigura() : FiguraGeo

    fun calcularVolume(raio : Double, altura : Double): Double{
        return 3.14 * raio * raio * altura
    }
}

class cone() : cilindroF(){

    override fun calcularAreaTotal(raio : Double, altura : Double): Double {
        var geratriz = Geratriz(raio, altura)
        return 3.14 * raio * (geratriz + raio)
    }

    fun calcularVolumeC(raio : Double, altura : Double) :  Double{
        var num = calcularVolume(altura, raio)
        return  num * 1/3
    }

    fun Geratriz(raio : Double, altura : Double) : Double{
        return sqrt((raio * raio) + (altura * altura))
    }

    override fun calcularFigura() : FiguraGeo{
        return FiguraGeo.Cone
    }
}

class cilindro() : cilindroF() {
    override fun calcularAreaTotal(raio : Double, altura : Double) : Double{
        return 2 * (2.14 * raio * raio) + 2 * (3.14 * raio * altura)
    }

    override fun calcularFigura() : FiguraGeo{
        return FiguraGeo.Cilindro
    }
}