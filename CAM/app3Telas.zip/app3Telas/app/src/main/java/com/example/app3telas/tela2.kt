package com.example.app3telas

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.app3telas.classes.esfera
import kotlinx.android.synthetic.main.tela2.*

class tela2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tela2)


        button_four.setOnClickListener {
            val intent = Intent(this, tela1::class.java)
            startActivity(intent)
        }
    }


    fun btCalcE(view: View){

        var esfera = esfera()
        textView.text = esfera.calcularFigura().toString()

        textView5.text = esfera.calcularAreaTotal(editText.text.toString().toDouble()).toString()

        textView4.text = esfera.calcularVolume(editText.text.toString().toDouble()).toString()
    }
}
