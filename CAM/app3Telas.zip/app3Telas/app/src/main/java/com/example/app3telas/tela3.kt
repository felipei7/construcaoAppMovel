package com.example.app3telas

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.app3telas.classes.cilindro
import kotlinx.android.synthetic.main.tela3.*


class tela3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tela3)


        button_five.setOnClickListener {
            val intent = Intent(this, tela1::class.java)
            startActivity(intent)
        }
    }

    fun btCalcCi(view: View){

        var cilindro = cilindro()
        textView9.text = cilindro.calcularFigura().toString()

        textView2.text = cilindro.calcularAreaTotal(editText4.text.toString().toDouble(), editText5.text.toString().toDouble()).toString()

        textView8.text = cilindro.calcularVolume(editText4.text.toString().toDouble(), editText5.text.toString().toDouble()).toString()
    }
}
