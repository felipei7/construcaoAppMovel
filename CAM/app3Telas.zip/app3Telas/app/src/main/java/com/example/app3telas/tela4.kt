package com.example.app3telas

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.app3telas.classes.cone
import kotlinx.android.synthetic.main.tela4.*

class tela4 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tela4)


        button_six.setOnClickListener {
            val intent = Intent(this, tela1::class.java)
            startActivity(intent)
        }
    }

    fun btCalcC(view: View){

        var cone = cone()
        textView3.text = cone.calcularAreaTotal(editText2.text.toString().toDouble(),editText3.text.toString().toDouble()).toString()

        textView6.text = cone.calcularVolumeC(editText2.text.toString().toDouble(),editText3.text.toString().toDouble()).toString()

        textView7.text = cone.calcularFigura().toString()
    }

}
