package com.example.app3telas

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.tela1.*

class tela1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tela1)

        button_one.setOnClickListener {
            val intent = Intent(this, tela2::class.java)
            startActivity(intent)
        }

        button_two.setOnClickListener {
            val intent = Intent(this, tela3::class.java)
            startActivity(intent)
        }

        button_three.setOnClickListener {
            val intent = Intent(this, tela4::class.java)
            startActivity(intent)
        }
    }

}
