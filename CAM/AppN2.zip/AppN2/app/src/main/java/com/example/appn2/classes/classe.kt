package com.example.appn2.classes

enum class Meses(var shorthand: String) {
    Janeiro("Janeiro"),
    Fevereiro("Fevereiro"),
    Março("Março"),
    Abril("Abril"),
    Maio("Maio"),
    Junho("Junho"),
    Julho("Julho"),
    Agosto("Agosto"),
    Setembro("Setembroo"),
    Outubro("Outubro"),
    Novembro("Novembro"),
    Dezembro("Dezembro"),
    Erro("Mês inválido!")
}

interface Mes{
    fun Num(num : Int) : Meses
}

abstract class MesImp : Mes {
    abstract fun VerEstacao(mes: Int): String

    override fun Num(num: Int): Meses {
        if (num == 1) return Meses.Janeiro
        else if (num == 2) return Meses.Fevereiro
        else if (num == 3) return Meses.Março
        else if (num == 4) return Meses.Abril
        else if (num == 5) return Meses.Maio
        else if (num == 6) return Meses.Junho
        else if (num == 7) return Meses.Julho
        else if (num == 8) return Meses.Agosto
        else if (num == 9) return Meses.Setembro
        else if (num == 10) return Meses.Outubro
        else if (num == 11) return Meses.Novembro
        else if (num == 12) return Meses.Dezembro
        else return Meses.Erro
    }
}

class Calcular() : MesImp() {

    override fun VerEstacao(mes: Int): String {
        if (mes == 4 || mes == 5 || mes == 6) return "Outono"
        else if (mes == 7 || mes == 8 || mes == 9) return "Inverno"
        else if (mes == 10 || mes == 11 || mes == 12) return "Primavera"
        else if (mes == 1 || mes == 2 || mes == 3) return "Verão"
        else return "Mês inválido"
    }
}

class Feriado(){
    fun Fer(mes: Int): String{
        if (mes == 4 || mes == 5 || mes == 6) return "3 Feriado"
        else if (mes == 7 || mes == 8 || mes == 9) return "0 Feriados"
        else if (mes == 10 || mes == 11 || mes == 12) return "2 Feriados"
        else if (mes == 1 || mes == 2 || mes == 3) return "1 Feriado"
        else return "Mês inválido"
    }
}
