package com.example.appn2

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.appn2.classes.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun btEnum(view: View){

        var meses = Calcular()
        textView_resposta.text = meses.Num(editText_entrada.text.toString().toInt()).toString()


        var estacao = Calcular()
        textView_resposta2.text = estacao.VerEstacao(editText_entrada.text.toString().toInt())

        var feriado = Feriado()
        textView_resposta3.text = feriado.Fer(editText_entrada.text.toString().toInt())

    }
}
