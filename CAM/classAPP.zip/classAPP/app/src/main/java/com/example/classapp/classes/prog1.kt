package com.example.classapp.classes

import android.view.View
import kotlinx.android.synthetic.main.programa1.*
import kotlinx.android.synthetic.main.programa4.*


class IMC(val nome: String, var altura: Float, var peso: Float) {
    fun calcularIMC(): String {
        val imc = ((peso)/(altura*altura))*10000

        val resposta = when(imc){
            in 0..19 -> "$nome você está abaixo do peso ideal"
            in 20..25 -> "$nome você está no peso Normal"
            in 26..30 -> "$nome você está com excesso de peso"
            in 31..35 -> "$nome você está com obesidade"
            else -> "$nome você está com obesidade Mórbita"
        }

        return resposta
    }
}

class Triangulo(val A: Int , var B: Int, var C: Int) {
    fun btTriangulo(): String {

        val resposta : String

        resposta = when((A < (B+C)) && (B < (A+C)) && (C < (A+B)) ){
            (A == B) && ( B == C) -> "Esses valores formas um triangulo. E ele é Equilatero"
            (A == B) || (B == C) || (A == C) -> "Esses valores formas um triangulo. E ele é Isósceles"
            (A != B) || (B != C) || (A != C) -> "Esses valores formas um triangulo. E ele é Escaleno"
            else -> "Esses válores não formam um triângulo"
        }

        return resposta
    }
}

class btPeso(val pesoTerra: Float, val nomePlaneta: String){
    fun btPeso(): String{

        val pesoPlaneta : Float
        val gravidadeRelativa : Float

        when{
            nomePlaneta == "jupiter" -> gravidadeRelativa = 2.64f
            nomePlaneta == "saturno" -> gravidadeRelativa = 1.15f
            else -> gravidadeRelativa = 1.17f
        }

        pesoPlaneta = (pesoTerra * gravidadeRelativa)/10f

        pesoPlaneta.toString()

        return ("$pesoTerra kg na terra é igual a $pesoPlaneta kg em $nomePlaneta")
    }
}


class btCoordenadas(val x : Int, val y: Int){
    fun btCoordenadas(): String{

        val resposta : String

        resposta = when{
            x > 0 && y > 0 -> "Primeiro quadrante"
            x < 0 && y > 0 -> "Segundo quadrante"
            x < 0 && y < 0 -> "Terceiro quadrante"
            x > 0 && y < 0 -> "Quarto quadrante"
            x == 0 && y != 0 -> "Está no eixo X"
            x != 0 && y == 0 -> "Está no eixo Y"
            else -> "Está na origem"
        }

        return resposta
    }
}
