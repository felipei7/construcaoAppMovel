package com.example.classapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.classapp.classes.btCoordenadas
import kotlinx.android.synthetic.main.programa1.*


class programa1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.programa1)

        btn_0.setOnClickListener {
            val intent = Intent(this, programa2::class.java)
            startActivity(intent)
        }

        btn_1.setOnClickListener {
            val intent = Intent(this, programa3::class.java)
            startActivity(intent)
        }
        btn_2.setOnClickListener {
            val intent = Intent(this, programa4::class.java)
            startActivity(intent)
        }
    }


    fun btCoordenadas(view:View){
        val coordenada = btCoordenadas(editText3_Coord1.text.toString().toInt(), editText2_Cood2.text.toString().toInt())

        textView_Saida2.text = coordenada.btCoordenadas()
    }



}
