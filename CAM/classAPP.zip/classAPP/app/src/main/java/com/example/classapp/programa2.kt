package com.example.classapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.classapp.classes.btPeso
import kotlinx.android.synthetic.main.programa2.*

class programa2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.programa2)

        btn_10.setOnClickListener {
            val intent = Intent(this, programa1::class.java)
            startActivity(intent)
        }

        btn_11.setOnClickListener {
            val intent = Intent(this, programa3::class.java)
            startActivity(intent)
        }

        btn_12.setOnClickListener {
            val intent = Intent(this, programa4::class.java)
            startActivity(intent)
        }
    }


    fun btPeso(view: View){
        val btPeso = btPeso(editText2_PesoNaTerra.text.toString().toFloat(), editText_NomeDoPlaneta.text.toString())
        textView_Saida3.text = btPeso.btPeso()
    }

}
