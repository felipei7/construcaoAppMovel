package com.example.classapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.classapp.classes.IMC
import kotlinx.android.synthetic.main.programa4.*

class programa4 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.programa4)


        btn_3.setOnClickListener {
            val intent = Intent(this, programa1::class.java)
            startActivity(intent)
        }

        btn_4.setOnClickListener {
            val intent = Intent(this, programa2::class.java)
            startActivity(intent)
        }

        btn_5.setOnClickListener {
            val intent = Intent(this, programa3::class.java)
            startActivity(intent)
        }
    }


    fun btIMC(view: View){
        val imc = IMC(editText_Nome.text.toString(),editText2_Peso.text.toString().toFloat(), editText3_Altura.text.toString().toFloat())
        textView5_Saida.text = imc.calcularIMC()
    }
}
