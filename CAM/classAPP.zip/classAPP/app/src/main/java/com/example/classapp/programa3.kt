package com.example.classapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.classapp.classes.Triangulo
import kotlinx.android.synthetic.main.programa3.*

class programa3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.programa3)

        btn_6.setOnClickListener {
            val intent = Intent(this, programa1::class.java)
            startActivity(intent)
        }

        btn_7.setOnClickListener {
            val intent = Intent(this, programa2::class.java)
            startActivity(intent)
        }

        btn_8.setOnClickListener {
            val intent = Intent(this, programa4::class.java)
            startActivity(intent)
        }
    }


    fun btTriangulo(view: View){
        val triangulo = Triangulo(editText6_A.text.toString().toInt(),editText7_B.text.toString().toInt(), editText8_C.text.toString().toInt())
        textView4_Saida.text = triangulo.btTriangulo()
    }
}
