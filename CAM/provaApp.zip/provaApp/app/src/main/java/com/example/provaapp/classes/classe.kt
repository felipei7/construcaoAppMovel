package com.example.provaapp.classes

import kotlin.Exception
import kotlin.math.sqrt

class PreenchaOsCampos(message: String): Exception(message)

//Calcular fatorial do número
class Fatorial(var numero:Int){

    fun CalcularFat():String{

        var resultado = 1

        while (numero != 1) {
            resultado = (resultado * numero)
            numero--
        }

        return resultado.toString()
    }
}


//Calculer se um número é um número perfeito
class Perfeito(var numero: Int) {
    fun CalcularPer():String {

        var soma = 0

        for (i in 1..(numero-1)) {
            if (numero % i == 0){
                soma = soma + i
            }
        }

        if (numero == soma) return "É um número perfeito"
        else return "Não é um número perfeito"
    }
}


//Calcular se um número é Capicua
class Capicua(var numero: Int){
    fun CalcularCap():String{

            val num = numero
            var inv = 0

            do{
                inv = inv * 10 + (numero%10)
                numero = numero/10;
            }while(numero>0)

            if(inv == num) return "É cápicua"
                else return "Não é capicua"
    }
}


//Calcular se um número é Quadrado Perfeito
class Qperfeito(var numero: Double){
    fun CalcularQper(): String{

        var mod = sqrt(numero)

        when{
        Math.pow(mod, 2.0) == numero -> return "É um quadrado perfeito"
            else -> return "Não é um quadrado perfeito"
        }
    }
}


//Calcular se um número é primo
class Primo(var numero: Int){
    fun CalcularPrimo():String{

        var div = 0

        for (i in 1..numero){
            if(numero % i == 0) div++
        }

        if(div == 2) return "É primo"
            else return "Não é primo"
    }
}

//Converter um número para uma base selecionada
class Conversor(var numero: Int, var base: Int) {

    fun Converter(): String {
        var d = "0123456789ABCDEF"

        var resposta = ""

        while (numero > 0) {
            resposta = d[numero % base] + resposta
            numero /= base
        }

        return resposta
    }
}


//Conveter um número para base 2, 8 e 16 simultaneamente.
class ConverterGeral(var numero: Int){
    fun ConverterTodos():Array<String>{
        var d = "0123456789ABCDEF"

        var resposta2 = ""
        var resposta3 = ""
        var resposta4 = ""

        var num1 = numero
        var num2 = numero
        var num3 = numero


        while(num1 > 0) {
            resposta2 = d[num1 % 2] + resposta2
            num1 /= 2
        }

        while(num2 > 0) {
            resposta3 = d[num2 % 8] + resposta3
            num2 /= 8
        }

        while(num3 > 0) {
            resposta4 = d[num3 % 16] + resposta4
            num3 /= 16
        }

        val array:Array<String> = arrayOf(resposta2, resposta3, resposta4)

        return array
    }
}





