package com.example.provaapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.provaapp.classes.*
import kotlinx.android.synthetic.main.programa1.*

class programa1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.programa1)
    }

    // Botão para calcular somente o fatorial do número
    fun btFatorial(view: View) {

        try {
            if (editText_entrada.text.isNullOrBlank()) {
                throw PreenchaOsCampos("ATENÇÃO: Insira um número!")
            }

            var fatorial = Fatorial(editText_entrada.text.toString().toInt())
            textView_resposta.text = fatorial.CalcularFat()

        } catch (e: PreenchaOsCampos) {
            textView_resposta.text = e.message
        }

    }

    //Botão para calcular somente se um número é um número perfeito
    fun btPerfeito(view: View) {
        try {
            if (editText_entrada.text.isNullOrBlank()) {
                throw PreenchaOsCampos("ATENÇÃO: Insira um número!")
            }

            var perfeito = Perfeito(editText_entrada.text.toString().toInt())
            textView2_resposta.text = perfeito.CalcularPer()

        } catch (e: PreenchaOsCampos) {
            textView2_resposta.text = e.message
        }
    }

    //Botão para calcular somente se um número é capicua
    fun btCapicua(view: View) {
        try {
            if (editText_entrada.text.isNullOrBlank()) {
                throw PreenchaOsCampos("ATENÇÃO: Insira um número!")
            }

            var capicua = Capicua(editText_entrada.text.toString().toInt())
            textView3_resposta.text = capicua.CalcularCap()

        } catch (e: PreenchaOsCampos) {
            textView3_resposta.text = e.message
        }
    }

    //Botão para calcular somente se um número é quadrado perfeito
    fun btQperfeito(view: View) {
        try {
            if (editText_entrada.text.isNullOrBlank()) {
                throw PreenchaOsCampos("ATENÇÃO: Insira um número!")
            }

            var qperfeito = Qperfeito(editText_entrada.text.toString().toDouble())
            textView4_resposta.text = qperfeito.CalcularQper()

        } catch (e: PreenchaOsCampos) {
            textView4_resposta.text = e.message
        }
    }

    //Botão para calcular somente se um número é primo
    fun btPrimo(view: View) {
        try {
            if (editText_entrada.text.isNullOrBlank()) {
                throw PreenchaOsCampos("ATENÇÃO: Insira um número!")
            }

            var primo = Primo(editText_entrada.text.toString().toInt())
            textView5_resposta.text = primo.CalcularPrimo()

        } catch (e: PreenchaOsCampos) {
            textView5_resposta.text = e.message
        }
    }

    //Botão para converter um número da base decimal para outra escolhida pelo usúario
    fun btConverter(vire: View) {
        try {
            if (editText_entrada.text.isNullOrBlank()) {
                throw PreenchaOsCampos("ATENÇÃO: Insira um número!")
            }

            if (editText2_entrada.text.isNullOrBlank()) {
                throw PreenchaOsCampos("ATENÇÃO: Insira uma base!")
            }


            var conversor = Conversor(editText_entrada.text.toString().toInt(), editText2_entrada.text.toString().toInt())
            textView6_resposta.text = conversor.Converter()

        } catch (e: PreenchaOsCampos) {
            textView6_resposta.text = e.message
        }
    }


    //Botão para calcular todos as possibilidades de uma vez
    fun btGeral(view: View){
        try {
            if (editText_entrada.text.isNullOrBlank()) {
                throw PreenchaOsCampos("ATENÇÃO: Preencha os valores!")
            }

            var fatorial = Fatorial(editText_entrada.text.toString().toInt())
            textView_resposta.text = fatorial.CalcularFat()

            var perfeito = Perfeito(editText_entrada.text.toString().toInt())
            textView2_resposta.text = perfeito.CalcularPer()

            var capicua = Capicua(editText_entrada.text.toString().toInt())
            textView3_resposta.text = capicua.CalcularCap()

            var qperfeito = Qperfeito(editText_entrada.text.toString().toDouble())
            textView4_resposta.text = qperfeito.CalcularQper()

            var primo = Primo(editText_entrada.text.toString().toInt())
            textView5_resposta.text = primo.CalcularPrimo()


            var conventer = ConverterGeral(editText_entrada.text.toString().toInt())
            textView7_resposta.text = conventer.ConverterTodos()[0]
            textView8_resposta.text = conventer.ConverterTodos()[1]
            textView9_resposta.text = conventer.ConverterTodos()[2]

        } catch (e: PreenchaOsCampos) {
            textView_resposta.text = e.message
            textView2_resposta.text = e.message
            textView3_resposta.text = e.message
            textView4_resposta.text = e.message
            textView5_resposta.text = e.message
        }
    }
}
