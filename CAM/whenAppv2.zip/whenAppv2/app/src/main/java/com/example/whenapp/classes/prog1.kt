package com.example.whenapp.classes

class Pessoa(val nomeCompleto:String, var peso:Double, var altura:Int){
    fun calcularIMC():Double{
        return peso/(altura*altura)
    }
}