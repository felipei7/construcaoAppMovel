package com.example.whenapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.programa1.*
import com.example.whenapp.classes.Pessoa

class programa1 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.programa1)

        btn_0.setOnClickListener {
            val intent = Intent(this, programa2::class.java)
            startActivity(intent)
        }

        btn_1.setOnClickListener {
            val intent = Intent(this, programa1::class.java)
            startActivity(intent)
        }
        btn_2.setOnClickListener {
            val intent = Intent(this, programa1::class.java)
            startActivity(intent)
        }
    }

    fun btCoordenadas(view : View){

        val x = editText3_Coord1.text.toString().toInt()
        val y = editText2_Cood2.text.toString().toInt()

        val resposta : String

        resposta = when{
            x > 0 && y > 0 -> "Primeiro quadrante"
            x < 0 && y > 0 -> "Segundo quadrante"
            x < 0 && y < 0 -> "Terceiro quadrante"
            x > 0 && y < 0 -> "Quarto quadrante"
            x == 0 && y != 0 -> "Está no eixo X"
            x != 0 && y == 0 -> "Está no eixo Y"
            else -> "Está na origem"
        }

        textView_Saida2.text = resposta
    }
}
