package com.example.whenapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.programa3.*

class programa3 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.programa3)

        btn_6.setOnClickListener {
            val intent = Intent(this, programa1::class.java)
            startActivity(intent)
        }

        btn_7.setOnClickListener {
            val intent = Intent(this, programa2::class.java)
            startActivity(intent)
        }

        btn_8.setOnClickListener {
            val intent = Intent(this, programa4::class.java)
            startActivity(intent)
        }
    }

    fun btTriangulo(view: View){

        val A = editText6_A.text.toString().toInt()
        val B = editText7_B.text.toString().toInt()
        val C = editText8_C.text.toString().toInt()

        val resposta : String

        resposta = when((A < (B+C)) && (B < (A+C)) && (C < (A+B)) ){
            (A == B) && ( B == C) -> "Esses valores formas um triangulo. E ele é Equilatero"
            (A == B) || (B == C) || (A == C) -> "Esses valores formas um triangulo. E ele é Isósceles"
            (A != B) || (B != C) || (A != C) -> "Esses valores formas um triangulo. E ele é Escaleno"
            else -> "Esses válores não formam um triângulo"
        }

        textView4_Saida.text = resposta
    }
}
